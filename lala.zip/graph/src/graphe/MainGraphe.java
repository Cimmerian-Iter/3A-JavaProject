package graphe;

public class MainGraphe {

	public static void main(String[] args) {
		Graphe G = new Graphe(5);
		G.addArete(0,3,1);
		G.addArete(2,3,1);
		G.addArete(2,4,2);
		G.addArete(1,4,1);
		G.addArete(1,3,5);
		G.coloration();
		System.out.println(G.toDOT());
		System.out.println(G.toDOT(G.BFS(0)));
		System.out.println(G.degreMax());
	}

}
