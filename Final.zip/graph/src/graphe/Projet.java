package graphe;
public class Projet {

	  public static void main(String[] args) throws Exception
	  {
		String path = "C:\\\\Users\\\\Samilop\\\\Desktop\\\\log.txt"; //on ins�re le chemin du fichier
	    String data = Fonctions.readFileAsString(path); //Il stock le fichier sous forme de texte
	    System.out.println(data); //Fonction de d�boguage pour voir si data est une valeur valide
	    int lines = Fonctions.countLines(data);//On compte le nombre de lines que poss�de le fichier
	    System.out.println(lines);
	    
	    String [] stringArr = Fonctions.lines(path);//On stoque le fichier sous forme de tableau pour mieux naviguer dedans
	    
	    Graphe G = new Graphe(lines);
	    
	    Fonctions.graph(stringArr, lines, G);
	    System.out.println(G.toDOT()); 
	    
	    System.out.println(Fonctions.couleur(stringArr, lines, G));
	    
	    	
	    	
	    }
	    	
	  }
	  
	  
	

