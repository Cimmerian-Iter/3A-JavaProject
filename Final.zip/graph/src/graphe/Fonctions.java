package graphe;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class Fonctions {
	public static String readFileAsString(String fileName)throws Exception
	  {
	    String data = "";
	    data = new String(Files.readAllBytes(Paths.get(fileName)));
	    return data;//On r�cup�re le texte sous forme de string
	  }
	  
	  public static int countLines(String str)
	  {
	      if (str == null || str.length() == 0)
	          return 0;
	      int lines = 1;
	      int len = str.length();
	      for( int pos = 0; pos < len; pos++) {
	          char c = str.charAt(pos);//On fait defiler chaque caract�re du texte
	          if( c == '\r' ) {
	              lines++;
	              if ( pos+1 < len && str.charAt(pos+1) == '\n' )
	                  pos++;
	          } else if( c == '\n' ) {
	              lines++;//On detecte a chaque fois qu'il y a un passage a la ligne pour compter le nombre de lignes
	          }
	      }
	      return lines;
	  }
	  
	  //La fonction suivante stock le texte sous forme de tableau pour une meilleur navigation
	  public static String[] lines(String path) throws IOException {
		    BufferedReader in = new BufferedReader(new FileReader(path));
		    String str;

		    List<String> list = new ArrayList<String>();
		    while((str = in.readLine()) != null){
		        list.add(str);
		 
	  }
		    String[] stringArr = list.toArray(new String[0]); 
		    return stringArr;
	  }
	  
	  //La fonction suivante transforme le .dot en instance de graph
	  public static void graph(String[] stringArr, int lines, Graphe G) { 
		  for (int i=1; i<lines-1;i++) {
		    	int sommet1 = stringArr[i].charAt(1) -48;//On soustrait 48 car la valeur en int du charAt (le sommet) est �gal au chiffre + 48
		    	int sommet2 = stringArr[i].charAt(10) -48;
		    	int poid = stringArr[i].charAt(22) -48;//On r�cup�re le poid
		    	G.addArete(sommet1,sommet2,poid);//On ajoute l'arrete au graph
		    	}
		    }
	  public static String couleur(String[] stringArr, int lines, Graphe G) {
		  String couleur_arrete="";
		  for (int i=1; i<lines-1;i++) {
			  int sommet1 = stringArr[i].charAt(1) -48;
			  int sommet2 = stringArr[i].charAt(10) -48;
		  
			  if (stringArr[i].charAt(23)==',') {
		    	
	    		int i1=30;//position de la virgule
	    			String couleur="";
	    			while (stringArr[i].charAt(i1)!= ']'){
	    				//fonction pour stocker la couleur
	    					couleur+=stringArr[i].charAt(i1);
	    						i1+=1;//On continue d'ajouter les lettres pour former le mot de la couleur correspondante
	    			}
	    		couleur_arrete+=sommet1+couleur+sommet2+"\n";
		    
			  	}
		  }
		  return couleur_arrete;
		  
	
}
	  public static void digraph(String[] stringArr, int lines, Graphe G) { 
		  for (int i=1; i<lines-1;i++) {
			  if (stringArr[i].charAt(7)=='>') {
				  //La fleche est dans ce sens ->
				  int sommet1 = stringArr[i].charAt(1) -48;//On soustrait 48 car la valeur en int du charAt (le sommet) est �gal au chiffre + 48
				  int sommet2 = stringArr[i].charAt(10) -48;
				  int poid = stringArr[i].charAt(22) -48;//On r�cup�re le poid
				  G.addArete(sommet1,sommet2,poid);//On ajoute l'arrete au graph
		    	}
			  else {
				  //La fleche est dans l'autre sens <- donc on inverse les sommet dans le add Arete pour que l'instance de graph les met dans le bonne ordre pour la cr�ation du graph orient� apr�s
				  int sommet1 = stringArr[i].charAt(10) -48;//On soustrait 48 car la valeur en int du charAt (le sommet) est �gal au chiffre + 48
				  int sommet2 = stringArr[i].charAt(1) -48;
				  int poid = stringArr[i].charAt(22) -48;//On r�cup�re le poid
				  G.addArete(sommet1,sommet2,poid);//On ajoute l'arrete au graph
			  }
		    }
	  }
	  
	  public static void nom(String[] stringArr, String nom)
	  {
	    if (stringArr[0].charAt(0)=='d') {
	    	int i=7;
	    	while (stringArr[0].charAt(i)!= '{'){
	    		nom+=stringArr[0].charAt(i);
	    	}
	    }
	    else {
	    	int i=5;
	    	while (stringArr[0].charAt(i)!= '{'){
	    		nom+=stringArr[0].charAt(i);
	    	}
	    }
	  }
	  
	  public static void choixgraph(String[] stringArr, int lines, Graphe G) {
		    if (stringArr[0].charAt(0)=='d') {
		    	Fonctions.digraph(stringArr,lines,G); //On detecte si c'est un digraph
		    }
		    
		    else {
		    	Fonctions.graph(stringArr, lines, G);
		    }
	  }
	  
	  public static void nombresommet(String[] stringArr, int lines, int imax) {
		  for (int i=1; i<lines-1;i++) {
			  int sommet1 = stringArr[i].charAt(1) -48;
			  int sommet2 = stringArr[i].charAt(10) -48;
			  
			  if (sommet1 > imax) {
				  imax = sommet1;
			  }
			  
			  if (sommet2 > imax) {
				  imax=sommet2;
			  }
		  
	  }
	  }
}

