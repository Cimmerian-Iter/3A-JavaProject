/**
 * 
 */
/**
 * @author vincent
 *
 */
module GraphePR1 {
}